package Commands;

import WorkCollection.Collection;
import WorkModuls.Answer;

public abstract class Commands {
    public abstract Answer commandDo(String key);
}
