package WorkModuls;

import WorkCollection.Collection;

public interface CreateCollection {
    Collection createCollection();
}
