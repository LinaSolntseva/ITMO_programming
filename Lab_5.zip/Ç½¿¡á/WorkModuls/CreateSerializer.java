package WorkModuls;

public interface CreateSerializer {
    SerializeCSV createSerializer();
}
