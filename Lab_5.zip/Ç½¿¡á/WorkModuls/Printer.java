package WorkModuls;

public class Printer {


    void printHint(String string){
        System.out.println(string);
    }

    void printAnswer(Answer answer){
        System.out.println(answer.getResult());
    }

}
