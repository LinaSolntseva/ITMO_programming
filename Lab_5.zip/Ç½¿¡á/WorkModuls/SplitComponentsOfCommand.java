package WorkModuls;

import java.util.ArrayList;

public interface SplitComponentsOfCommand {
    ArrayList<String> splitCommand(String command);
}
