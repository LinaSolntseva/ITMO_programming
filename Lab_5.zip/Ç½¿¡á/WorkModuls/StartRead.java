package WorkModuls;

import WorkCollection.Collection;

import java.io.IOException;

public interface StartRead {
    void startReadOfCommand(Collection collection) throws IOException;
}
