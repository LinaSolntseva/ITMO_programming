package WorkModuls;

import WorkCollection.Collection;

public interface WorkOfChooseCommand {
    ChooseCommand createChooseCommand(Collection collection);
}
