package WorkModuls;

public interface WorkWithAnswer {
    Answer createAnswer(String string);
}
