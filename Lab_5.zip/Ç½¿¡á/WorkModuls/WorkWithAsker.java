package WorkModuls;


public interface WorkWithAsker {
    Asker createAsker();
}
