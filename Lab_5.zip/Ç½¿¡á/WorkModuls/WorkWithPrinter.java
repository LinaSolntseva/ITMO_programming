package WorkModuls;

public interface WorkWithPrinter {
    Printer createPrinter();
}
