package WorkModuls;

public interface WorkWithTokenizer {
    TokenizerOfCommand createTokenizer();
}
